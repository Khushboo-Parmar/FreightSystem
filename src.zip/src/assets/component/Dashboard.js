// import React, { useState } from 'react';
// import { StyleSheet, Text, View, Image, TouchableOpacity } from 'react-native';
// import { useNavigation } from '@react-navigation/native';
// import { responsiveHeight, responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';
// import Icon from 'react-native-vector-icons/Ionicons';
// import { useSelector } from 'react-redux';
// import Footer from './Footer/Footer';

// const Dashboard = () => {

//   const phoneNumber = useSelector(state => state.phone.phoneNumber);
//   const navigation = useNavigation();

//   return (
//     <View style={styles.container}>
//       <View style={styles.content}>
//         <Image style={styles.logo} source={require('../Images/BTIcon.png')} />
//         {/* <Text style={styles.heading}>Welcome to Bytegear Retailer</Text> */}
       
//        <View style={{backgroundColor:'black',paddingTop:responsiveHeight(4),borderRadius:300,paddingBottom:2.8}}>
//        <Image source={require('../Images/Deliver_boy.png')} style={{width: responsiveWidth(60),
// height: responsiveHeight(35.6)}} />
//        </View>
       
       
//         <View style={{ gap: responsiveHeight(2) }}>
//                     <Text style={{ textAlign: 'center', fontWeight: 'bold', color: 'black', fontSize: responsiveFontSize(3) }}>
//                         Welcome to the <Text style={{ color: '#0161e7', fontSize: responsiveFontSize(2.9) }}>Bytegear Retailer</Text> App
//                     </Text>
//                     <Text style={{ textAlign: 'center', color: 'black', fontSize: responsiveFontSize(1.5), fontWeight: '300' }}>
//                     Soham Web Solution All In One CRM{'\n'} Solution For Our Employes.
//                     </Text>
//                 </View>



// {/* 
//         <View style={styles.buttonContainer}>
//           <TouchableOpacity style={styles.button} onPress={() => { navigation.navigate('Loginphone'); }}>
//             <Icon name="log-in-outline" size={20} color="#fff" style={styles.icon} />
//             <Text style={styles.buttonText}>Login</Text>
//           </TouchableOpacity>
//           <TouchableOpacity style={styles.registerButton} onPress={() => { navigation.navigate('PhoneNoScreen'); }}>
//             <Icon name="person-add-outline" size={20} color="#fff" style={styles.icon} />
//             <Text style={styles.buttonText}>Register</Text>
//           </TouchableOpacity>
//         </View> */}
//       </View>
//       <View style={{width:'100%',paddingHorizontal:responsiveWidth(5)}}>
//             <TouchableOpacity onPress={()=>navigation.replace('Loginphone')} style={{borderWidth:1,borderColor:'black',width:'100%',paddingVertical:15,marginVertical:40,borderRadius:10,alignItems:'center'}}>
//                     <Text style={{fontSize: responsiveFontSize(2.2),color:'black',fontWeight:'bold'}} >Log In</Text>
//                 </TouchableOpacity>
//             </View>
//     </View>
//   );
// };

// export default Dashboard;

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: '#fff',
//     justifyContent: 'center',
//     alignItems: 'center',
//   },
//   bgImage: {
//     position: 'absolute',
//     width: '100%',
//     height: '100%',
//   },
//   content: {
//    justifyContent:'space-between',
//     alignItems: 'center',
//     padding: responsiveWidth(5),
//   },
//   logo: {
//     width: responsiveWidth(40),
//     height: responsiveWidth(20),
//     resizeMode: 'contain',
//     alignSelf: 'center',
//     marginBottom: responsiveHeight(2),
//   },
//   heading: {
//     fontSize: responsiveFontSize(3),
//     fontWeight: 'bold',
//     color: 'black',
//     marginBottom: responsiveHeight(5),
//     textAlign: 'center',
//   },
//   searchContainer: {
//     marginTop: responsiveHeight(3),
//   },
//   searchButton: {
//     backgroundColor: '#ee1d23',
//     paddingVertical: responsiveHeight(1.5),
//     paddingHorizontal: responsiveWidth(10),
//     borderRadius: 10,
//     elevation: 2, 
//     shadowColor: '#000', 
//     shadowOffset: { width: 0, height: 2 }, 
//     shadowOpacity: 0.8,
//     shadowRadius: 2, 
//     alignItems: 'center',
//     flexDirection: 'row',
//   },
//   searchText: {
//     color: '#fff',
//     fontSize: responsiveFontSize(2),
//     fontWeight: 'bold',
//     marginLeft: responsiveWidth(2),
//   },
//   buttonContainer: {
//     flexDirection: 'row',
//     justifyContent: 'center',
//     alignItems: 'center',
//   },
//   button: {
//     backgroundColor: '#000',
//     paddingVertical: responsiveHeight(2),
//     paddingHorizontal: responsiveWidth(10),
//     borderRadius: 30,
//     marginHorizontal: 10,
//     alignItems: 'center',
//     flexDirection: 'row',
//   },
//   registerButton: {
//     backgroundColor: '#ee1d23',
//     paddingVertical: responsiveHeight(2),
//     paddingHorizontal: responsiveWidth(10),
//     borderRadius: 30,
//     marginHorizontal: 10,
//     alignItems: 'center',
//     flexDirection: 'row',
//   },
//   buttonText: {
//     color: '#fff',
//     fontSize: responsiveFontSize(2),
//     fontWeight: 'bold',
//     textAlign: 'center',
//     marginLeft: responsiveWidth(2),
//   },
//   icon: {
//     marginRight: responsiveWidth(1),
//   },
// });



import React from 'react';
import { StyleSheet, Text, View, Image, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { responsiveHeight, responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';

const Dashboard = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <Image style={styles.logo} source={require('../Images/BTIcon.png')} />

        <View style={styles.imageContainer}>
          <Image
            source={require('../Images/Deliver_boy.png')}
            style={styles.deliverBoyImage}
          />
        </View>

        <View style={styles.textContainer}>
          <Text style={styles.welcomeText}>
            Welcome to the{' '}
            <Text style={styles.highlightedText}>Bytegear Retailer</Text> Business App
          </Text>
          <Text style={styles.descriptionText}>
          Empowering Retailers with Seamless Solutions{'\n'} for Efficient Business Management.
          </Text>
        </View>
      </View>

      <View style={styles.loginContainer}>
        <TouchableOpacity
          onPress={() => navigation.replace('Loginphone')}
          style={styles.loginButton}>
          <Text style={styles.loginButtonText}>Log In</Text>
        </TouchableOpacity>

        <Text style={styles.registerText}>
          Don't have an account?{' '}
          <Text
            style={styles.registerLink}
            onPress={() => navigation.navigate('PhoneNoScreen')}>
            Register here
          </Text>
        </Text>
      </View>
    </View>
  );
};

export default Dashboard;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    justifyContent: 'space-around',
    alignItems: 'center',
    // paddingVertical:responsiveHeight(4)
  },
  content: {
    justifyContent: 'center',
    alignItems: 'center',
    padding: responsiveWidth(5),
  },
  logo: {
    width: responsiveWidth(30),
    height: responsiveWidth(20),
    resizeMode: 'contain',
    marginBottom: responsiveHeight(5),
  },
  imageContainer: {
    backgroundColor: 'black',
    paddingVertical: responsiveHeight(4),
    borderRadius: 300,
    marginBottom: responsiveHeight(2.8),
  },
  deliverBoyImage: {
    width: responsiveWidth(50),
    height: responsiveHeight(30),
  },
  textContainer: {
    alignItems: 'center',
    gap: responsiveHeight(2),
  },
  welcomeText: {
    textAlign: 'center',
    fontWeight: 'bold',
    color: 'black',
    fontSize: responsiveFontSize(3),
  },
  highlightedText: {
    color: '#ee1d23',
    fontSize: responsiveFontSize(2.9),
  },
  descriptionText: {
    textAlign: 'center',
    color: 'black',
    fontSize: responsiveFontSize(1.5),
    fontWeight: '300',
  },
  loginContainer: {
    width: '100%',
    paddingHorizontal: responsiveWidth(5),
    marginBottom: responsiveHeight(5),
    gap:responsiveHeight(2)
  },
  loginButton: {
    borderWidth: 1,
    borderColor: '#ee1d23',
    paddingVertical: responsiveHeight(2),
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: responsiveHeight(1),
  },
  loginButtonText: {
    fontSize: responsiveFontSize(2.2),
    color: '#ee1d23',
    fontWeight: 'bold',
  },
  registerText: {
    textAlign: 'center',
    fontSize: responsiveFontSize(1.8),
    color: 'black',
  },
  registerLink: {
    color: '#ee1d23',
    fontWeight: 'bold',
  },
});
